// ─── Types ───────────────────────────────────────────────────────────────────

export interface FirstAidStep {
  stepNumber: number;
  instruction: string;
  detail: string;
  criticalWarning?: string;
  audioText: string;
}

export interface EmergencyScenario {
  id: string;
  title: string;
  category: 'Critical Life Support' | 'Trauma & Injury' | 'Environmental & Allergic';
  severity: 'CRITICAL' | 'URGENT' | 'STABLE';
  estimatedTime: string;
  overview: string;
  quickActionBadge: string;
  hasArGuide: boolean;
  arRoute?: string;
  steps: FirstAidStep[];
  dos: string[];
  donts: string[];
}

// ─── Data ────────────────────────────────────────────────────────────────────

export const emergencyScenarios: EmergencyScenario[] = [
  // ── Critical Life Support ──────────────────────────────────────────────────
  {
    id: "cpr",
    title: 'CPR (Cardiopulmonary Resuscitation)',
    category: 'Critical Life Support',
    severity: 'CRITICAL',
    estimatedTime: '~20 min until EMS',
    overview:
      'Cardiopulmonary resuscitation is the primary intervention when a person is found unresponsive and not breathing normally. High-quality chest compressions maintain perfusion to the brain and heart until advanced medical help arrives.',
    quickActionBadge: 'Start Compressions NOW',
    hasArGuide: true,
    arRoute: '/ar-first-aid?type=cpr',
    steps: [
      {
        stepNumber: 1,
        instruction: 'Check Responsiveness',
        detail:
          'Tap the person firmly on both shoulders and shout "Are you okay?" Look for any movement, sound, or eye opening. Check for no more than 10 seconds.',
        criticalWarning: 'Do NOT shake the person if a spinal injury is suspected.',
        audioText: 'Tap both shoulders firmly and shout: Are you okay? Look for any response for up to 10 seconds.',
      },
      {
        stepNumber: 2,
        instruction: 'Call Emergency Services (112)',
        detail:
          'If the person is unresponsive, immediately call 112 or ask a bystander to call. Put the phone on speaker. Request an AED if available nearby.',
        audioText: 'Call 112 immediately. Put the phone on speaker. Ask someone nearby to fetch an AED.',
      },
      {
        stepNumber: 3,
        instruction: 'Check Breathing',
        detail:
          'Tilt the head back gently and lift the chin. Look at the chest for movement, listen for breath sounds, and feel for airflow on your cheek. Take no more than 10 seconds.',
        criticalWarning: 'Occasional gasps are NOT normal breathing — begin CPR.',
        audioText: 'Tilt the head back, lift the chin. Look, listen, and feel for breathing for up to 10 seconds. Gasps do not count as normal breathing.',
      },
      {
        stepNumber: 4,
        instruction: 'Position Your Hands',
        detail:
          'Kneel beside the person. Place the heel of one hand on the center of the chest (lower half of the sternum). Place your other hand on top and interlock your fingers. Keep your arms straight, shoulders directly over your hands.',
        audioText: 'Kneel beside the person. Place the heel of one hand on the center of the chest. Stack the other hand on top and interlock your fingers. Keep arms straight.',
      },
      {
        stepNumber: 5,
        instruction: 'Begin Chest Compressions',
        detail:
          'Push hard and fast at a rate of 100–120 compressions per minute. Compress the chest at least 5 cm deep. Allow full chest recoil between each compression. Minimise interruptions.',
        criticalWarning: 'Do NOT stop compressions for more than 10 seconds at any point.',
        audioText: 'Push hard and fast! Compress at least 5 centimetres deep at 100 to 120 beats per minute. Let the chest fully recoil each time.',
      },
      {
        stepNumber: 6,
        instruction: 'Continue Until Help Arrives',
        detail:
          'Continue CPR without stopping until paramedics take over, an AED becomes available and advises a shock, or the person shows clear signs of life (conscious movement, coughing, normal breathing).',
        audioText: 'Keep going. Continue CPR until paramedics arrive, an AED is ready, or the person shows signs of life.',
      },
    ],
    dos: [
      'Push hard (≥5 cm) and fast (100–120/min)',
      'Allow full chest recoil between compressions',
      'Minimise interruptions to less than 10 seconds',
      'Switch rescuers every 2 minutes to avoid fatigue',
      'Use an AED as soon as one arrives',
    ],
    donts: [
      'Don\'t delay compressions to look for a pulse',
      'Don\'t lean on the chest between compressions',
      'Don\'t interrupt CPR to move the patient unless in danger',
      'Don\'t give up — brain damage begins after 4–6 minutes without perfusion',
    ],
  },
  {
    id: "choking",
    title: 'Choking (Heimlich Maneuver)',
    category: 'Critical Life Support',
    severity: 'CRITICAL',
    estimatedTime: '~2–5 min',
    overview:
      'A foreign-body airway obstruction can rapidly become fatal. The Heimlich maneuver (abdominal thrusts) uses upward diaphragmatic pressure to expel the object. Speed is essential — act before the person loses consciousness.',
    quickActionBadge: 'Abdominal Thrusts NOW',
    hasArGuide: false,
    steps: [
      {
        stepNumber: 1,
        instruction: 'Confirm Choking',
        detail:
          'Ask "Are you choking?" Look for the universal choking sign (hands clutching the throat). If the person cannot speak, cough forcefully, or breathe, they have a severe obstruction.',
        audioText: 'Ask: Are you choking? If they cannot speak, cough, or breathe, they need immediate help.',
      },
      {
        stepNumber: 2,
        instruction: 'Call for Help',
        detail:
          'Shout for bystanders. Have someone call 112 while you begin abdominal thrusts. If alone, perform thrusts first — call after the airway clears or the person becomes unconscious.',
        audioText: 'Have someone call 112. Begin abdominal thrusts immediately.',
      },
      {
        stepNumber: 3,
        instruction: 'Position Yourself Behind the Person',
        detail:
          'Stand directly behind the choking person. Wrap both arms around their waist. Lean them slightly forward.',
        audioText: 'Stand behind the person. Wrap your arms around their waist and lean them slightly forward.',
      },
      {
        stepNumber: 4,
        instruction: 'Perform Abdominal Thrusts',
        detail:
          'Make a fist with one hand and place the thumb side against the abdomen, just above the navel and well below the breastbone. Grasp the fist with your other hand and deliver quick, inward-and-upward thrusts.',
        criticalWarning: 'For pregnant or obese individuals, use chest thrusts instead (hands on the center of the breastbone).',
        audioText: 'Place your fist above the navel. Grasp it with the other hand. Give quick upward thrusts.',
      },
      {
        stepNumber: 5,
        instruction: 'Repeat Until Object is Expelled',
        detail:
          'Continue cycles of 5 abdominal thrusts. Check the mouth for the expelled object between cycles. If the person becomes unconscious, lower them to the ground and begin CPR — check the airway before each rescue breath.',
        audioText: 'Repeat thrusts in sets of five. If the person goes unconscious, start CPR immediately and check the airway.',
      },
    ],
    dos: [
      'Act fast — seconds count with a complete obstruction',
      'Use chest thrusts for pregnant or obese victims',
      'Start CPR immediately if the person loses consciousness',
      'Look in the mouth for the object before each rescue breath',
    ],
    donts: [
      'Don\'t perform abdominal thrusts on infants — use back blows and chest thrusts',
      'Don\'t do a blind finger sweep (you may push the object deeper)',
      'Don\'t slap the person on the back while they\'re upright (can lodge the object further)',
    ],
  },
  {
    id: "anaphylaxis",
    title: 'Anaphylaxis (Severe Allergic Reaction)',
    category: 'Critical Life Support',
    severity: 'CRITICAL',
    estimatedTime: '~5 min (epinephrine critical)',
    overview:
      'Anaphylaxis is a rapid, life-threatening allergic reaction involving airway swelling, vascular collapse, or both. Epinephrine is the only first-line treatment — antihistamines cannot reverse anaphylaxis.',
    quickActionBadge: 'Inject EpiPen NOW',
    hasArGuide: false,
    steps: [
      {
        stepNumber: 1,
        instruction: 'Recognise the Signs',
        detail:
          'Look for swelling of the face/lips/tongue, difficulty breathing or wheezing, hives or widespread rash, dizziness, rapid weak pulse, nausea, or a sense of impending doom. Symptoms usually develop within minutes of exposure.',
        audioText: 'Look for swelling, breathing difficulty, hives, dizziness, or a rapid weak pulse. These are signs of anaphylaxis.',
      },
      {
        stepNumber: 2,
        instruction: 'Call 112 Immediately',
        detail:
          'Anaphylaxis can deteriorate in minutes. Call emergency services even if epinephrine is given — the person needs hospital observation for at least 4 hours (biphasic reactions can recur).',
        audioText: 'Call 112 now. Even after epinephrine, the person needs hospital monitoring.',
      },
      {
        stepNumber: 3,
        instruction: 'Administer Epinephrine Auto-Injector',
        detail:
          'If the person carries an EpiPen or similar device: remove the safety cap, press firmly into the outer mid-thigh (through clothing is fine), and hold for 10 seconds. Note the exact time of injection.',
        criticalWarning: 'Do NOT inject into a vein, buttock, hand, or foot. Outer mid-thigh ONLY.',
        audioText: 'Use the epinephrine auto-injector on the outer mid-thigh. Hold for 10 seconds. Note the time.',
      },
      {
        stepNumber: 4,
        instruction: 'Position the Person',
        detail:
          'Lay them flat on their back with legs elevated (shock position). If they have breathing difficulty or are vomiting, sit them up slightly. If unconscious and breathing, place in recovery position.',
        criticalWarning: 'Do NOT stand the person up or have them walk — sudden changes in position can cause cardiac arrest.',
        audioText: 'Lay the person flat with legs raised. If they are struggling to breathe, sit them up slightly.',
      },
      {
        stepNumber: 5,
        instruction: 'Monitor & Prepare for Second Dose',
        detail:
          'Watch for improvement within 5 minutes. If symptoms persist or worsen, administer a second epinephrine dose (opposite thigh). Continue monitoring breathing and consciousness until EMS arrives.',
        audioText: 'Monitor for 5 minutes. If no improvement, give a second epinephrine dose in the other thigh.',
      },
    ],
    dos: [
      'Give epinephrine as the FIRST treatment — do not delay',
      'Call 112 even if symptoms improve after epinephrine',
      'Keep the person lying down with legs elevated',
      'Note the time of each epinephrine injection',
      'Be prepared to perform CPR if the person becomes unresponsive',
    ],
    donts: [
      'Don\'t rely on antihistamines alone — they cannot reverse anaphylaxis',
      'Don\'t let the person stand or walk',
      'Don\'t delay epinephrine because you\'re unsure — the risk of not treating is far greater',
      'Don\'t remove the allergen if it causes further injury (e.g. an embedded stinger — scrape, don\'t squeeze)',
    ],
  },

  // ── Trauma & Injury ───────────────────────────────────────────────────────
  {
    id: "severe-bleeding",
    title: 'Severe Bleeding Control',
    category: 'Trauma & Injury',
    severity: 'CRITICAL',
    estimatedTime: '~5–10 min',
    overview:
      'Uncontrolled haemorrhage is the leading cause of preventable death in trauma. Direct pressure controls most external bleeding. A tourniquet is required for life-threatening limb haemorrhage that direct pressure cannot control.',
    quickActionBadge: 'Apply Pressure NOW',
    hasArGuide: true,
    arRoute: '/emergency-scan',
    steps: [
      {
        stepNumber: 1,
        instruction: 'Ensure Scene Safety',
        detail:
          'Before approaching, confirm the scene is safe for you. Put on gloves or use a barrier (plastic bag, extra cloth) to protect yourself from bloodborne pathogens.',
        audioText: 'Check for safety. Put on gloves or use a barrier before touching blood.',
      },
      {
        stepNumber: 2,
        instruction: 'Call 112',
        detail:
          'Activate emergency services. Provide your location, state that there is severe bleeding, and follow dispatcher instructions.',
        audioText: 'Call 112. Tell them there is severe bleeding and give your location.',
      },
      {
        stepNumber: 3,
        instruction: 'Apply Direct Pressure',
        detail:
          'Use a clean cloth, gauze, or clothing and press firmly on the wound with both hands. Do not lift the dressing to check — if blood soaks through, add more layers on top.',
        criticalWarning: 'Do NOT remove the first cloth — adding layers preserves any clot formation.',
        audioText: 'Press firmly on the wound with a clean cloth or gauze. Do not lift it. If blood soaks through, add more cloth on top.',
      },
      {
        stepNumber: 4,
        instruction: 'Apply a Tourniquet (Limb Wounds)',
        detail:
          'If direct pressure cannot control bleeding from an arm or leg: apply a tourniquet 5–7 cm above the wound (not on a joint). Tighten until bleeding stops. Note the time of application.',
        criticalWarning: 'Once applied, do NOT remove or loosen the tourniquet — only medical professionals should remove it.',
        audioText: 'If direct pressure fails on a limb, apply a tourniquet above the wound. Tighten until bleeding stops. Note the time.',
      },
      {
        stepNumber: 5,
        instruction: 'Treat for Shock',
        detail:
          'Lay the person down and elevate the legs (unless the injury prevents it). Keep them warm with a blanket. Reassure them and monitor breathing until EMS arrives.',
        audioText: 'Lay the person down and raise their legs. Cover them with a blanket and keep them calm.',
      },
    ],
    dos: [
      'Apply firm, continuous direct pressure',
      'Add more cloth on top if blood soaks through',
      'Use a tourniquet for life-threatening limb bleeding',
      'Note the time a tourniquet is applied',
      'Keep the person warm and reassured',
    ],
    donts: [
      'Don\'t remove the initial dressing to check the wound',
      'Don\'t apply a tourniquet over a joint',
      'Don\'t use a tourniquet for non-limb wounds (neck, torso, groin)',
      'Don\'t give food or water to a bleeding patient',
    ],
  },
  {
    id: "fractures",
    title: 'Fractures & Bone Injuries',
    category: 'Trauma & Injury',
    severity: 'URGENT',
    estimatedTime: '~15–30 min until EMS',
    overview:
      'A fracture (broken bone) may present with pain, swelling, deformity, or inability to move the limb. The primary goal of first aid is to immobilise the injury and prevent further damage while awaiting professional care.',
    quickActionBadge: 'Immobilise & Splint',
    hasArGuide: false,
    steps: [
      {
        stepNumber: 1,
        instruction: 'Do Not Move the Injured Area',
        detail:
          'Keep the person still. Do not attempt to realign the bone or push a protruding bone back in. Support the limb in the position you find it.',
        criticalWarning: 'If the person may have a spinal injury, do NOT move them unless they are in immediate danger.',
        audioText: 'Do not move the injured area. Support the limb exactly as you find it.',
      },
      {
        stepNumber: 2,
        instruction: 'Call 112',
        detail:
          'Call emergency services for any suspected fracture. Describe the injury location, whether the bone is visible, and any loss of sensation or circulation below the injury.',
        audioText: 'Call 112. Describe the location of the fracture and any numbness or discoloration.',
      },
      {
        stepNumber: 3,
        instruction: 'Immobilise with a Splint',
        detail:
          'Use a rigid object (rolled magazine, board, stick) padded with cloth. Secure it above and below the fracture site with ties or bandages. The splint should prevent movement of the joints above and below the break.',
        audioText: 'Create a splint using a rigid object padded with cloth. Secure it above and below the fracture.',
      },
      {
        stepNumber: 4,
        instruction: 'Apply Ice & Manage Pain',
        detail:
          'Apply a cold pack or ice wrapped in cloth to the injury for 20 minutes on, 20 minutes off. This reduces swelling. Do not apply ice directly to skin.',
        audioText: 'Apply wrapped ice to the injury for 20 minutes to reduce swelling. Do not put ice directly on skin.',
      },
      {
        stepNumber: 5,
        instruction: 'Monitor Circulation Below the Injury',
        detail:
          'Check for warmth, colour, sensation, and pulse below the fracture site every 10 minutes. If the area becomes cold, pale, numb, or pulseless, loosen any bandages and call 112 again.',
        criticalWarning: 'Loss of circulation below a fracture is an emergency — it can lead to limb loss.',
        audioText: 'Check circulation below the fracture every 10 minutes. Look for warmth, colour, and pulse.',
      },
    ],
    dos: [
      'Immobilise the injury in the position found',
      'Splint above and below the break',
      'Apply wrapped ice to reduce swelling',
      'Check circulation below the injury regularly',
      'Keep the person comfortable and reassured',
    ],
    donts: [
      'Don\'t try to realign or push in a protruding bone',
      'Don\'t move the person if a spinal injury is possible',
      'Don\'t apply ice directly to skin',
      'Don\'t give the person anything to eat or drink (surgery may be needed)',
    ],
  },

  // ── Environmental & Allergic ──────────────────────────────────────────────
  {
    id: "burns",
    title: 'Burns (Thermal, Chemical & Electrical)',
    category: 'Environmental & Allergic',
    severity: 'URGENT',
    estimatedTime: '~20 min cooling + EMS',
    overview:
      'Burns destroy skin layers and can cause fluid loss, infection, and systemic shock. Cooling with clean running water is the single most effective first-aid intervention. The type of burn (thermal, chemical, or electrical) determines additional precautions.',
    quickActionBadge: 'Cool Under Water NOW',
    hasArGuide: false,
    steps: [
      {
        stepNumber: 1,
        instruction: 'Ensure Safety & Stop the Burning',
        detail:
          'Remove the person from the heat source, chemical, or electrical source. For chemical burns: brush off dry chemicals first, then flush with water. For electrical burns: ensure the power is OFF before touching the person.',
        criticalWarning: 'For electrical burns, do NOT touch the person until the power source is disconnected.',
        audioText: 'Remove the person from the burn source. For chemical burns, brush off dry chemicals first. For electrical burns, ensure the power is off.',
      },
      {
        stepNumber: 2,
        instruction: 'Cool the Burn with Running Water',
        detail:
          'Hold the burned area under cool (not cold) running water for a full 20 minutes. This is effective up to 3 hours after the burn. Remove jewellery and non-adherent clothing from the area while cooling.',
        criticalWarning: 'Do NOT use ice, iced water, or any creams/gels — these worsen the injury.',
        audioText: 'Run cool water over the burn for 20 minutes. Remove jewellery and loose clothing. Do not use ice or creams.',
      },
      {
        stepNumber: 3,
        instruction: 'Cover with a Clean Dressing',
        detail:
          'After cooling, cover the burn with cling film (lengthways, not wrapped around) or a clean, non-fluffy material. This protects the wound, retains moisture, and reduces pain from air contact.',
        audioText: 'Cover the burn with cling film laid lengthways, or a clean non-fluffy cloth.',
      },
      {
        stepNumber: 4,
        instruction: 'Manage Pain & Monitor for Shock',
        detail:
          'Give over-the-counter pain relief (paracetamol or ibuprofen) if available. For large burns, lay the person down, elevate the burned area if possible, and keep them warm with a blanket over un-burned areas.',
        audioText: 'Give pain relief if available. For large burns, lay the person down and keep them warm.',
      },
      {
        stepNumber: 5,
        instruction: 'Seek Medical Attention',
        detail:
          'Call 112 for: burns larger than the person\'s hand, burns on the face/hands/feet/genitals/joints, full-thickness (white/charred) burns, chemical or electrical burns, or any burn in a child or elderly person.',
        audioText: 'Call 112 for large, deep, chemical, or electrical burns, and for any burn in a child or elderly person.',
      },
    ],
    dos: [
      'Cool under running water for 20 minutes',
      'Remove jewellery and loose clothing early',
      'Cover with cling film or clean non-fluffy material',
      'Keep the person warm (cover un-burned areas)',
    ],
    donts: [
      'Don\'t use ice, iced water, or butter',
      'Don\'t apply creams, gels, or toothpaste',
      'Don\'t burst blisters — they protect the wound',
      'Don\'t remove clothing stuck to the burn',
    ],
  },
  {
    id: "seizures",
    title: 'Seizures (Epileptic & Other)',
    category: 'Environmental & Allergic',
    severity: 'URGENT',
    estimatedTime: '~5–10 min (most resolve on their own)',
    overview:
      'During a seizure, abnormal electrical activity in the brain causes involuntary movements and altered consciousness. Most seizures end on their own within 1–3 minutes. The rescuer\'s goal is to protect the person from injury and maintain their airway.',
    quickActionBadge: 'Protect & Time It',
    hasArGuide: false,
    steps: [
      {
        stepNumber: 1,
        instruction: 'Keep Calm & Time the Seizure',
        detail:
          'Note the exact time the seizure starts. Most seizures resolve within 1–3 minutes. A seizure lasting more than 5 minutes, or repeated seizures without regaining consciousness, is a medical emergency (status epilepticus).',
        criticalWarning: 'Call 112 immediately if the seizure lasts more than 5 minutes.',
        audioText: 'Stay calm. Start timing the seizure now. Call 112 if it lasts more than 5 minutes.',
      },
      {
        stepNumber: 2,
        instruction: 'Protect from Injury',
        detail:
          'Clear hard or sharp objects away from the person. Place something soft (jacket, cushion) under their head. Do NOT restrain their movements — let the seizure run its course.',
        audioText: 'Clear the area of dangerous objects. Place something soft under their head. Do not hold them down.',
      },
      {
        stepNumber: 3,
        instruction: 'Do NOT Put Anything in Their Mouth',
        detail:
          'It is a myth that a person having a seizure can swallow their tongue. Putting objects in the mouth can break teeth, injure the jaw, or cause aspiration.',
        criticalWarning: 'Never insert fingers, a wallet, a spoon, or any object into the mouth during a seizure.',
        audioText: 'Do not put anything in their mouth. They cannot swallow their tongue.',
      },
      {
        stepNumber: 4,
        instruction: 'Place in Recovery Position',
        detail:
          'Once the seizure stops, gently roll the person onto their side (recovery position). This keeps the airway clear and allows fluids to drain. Stay with them until they are fully aware.',
        audioText: 'After the seizure stops, gently roll them onto their side. Stay with them until they are fully alert.',
      },
      {
        stepNumber: 5,
        instruction: 'Reassure & Report',
        detail:
          'The person may be confused, sleepy, or embarrassed after a seizure (postictal phase). Speak calmly, explain what happened, and help them orient. Call 112 if this is their first seizure, they are injured, or they don\'t recover within 15 minutes.',
        audioText: 'Speak calmly and reassure them. Call 112 if this is their first seizure or they do not recover.',
      },
    ],
    dos: [
      'Time the seizure from the start',
      'Clear the area of hard or sharp objects',
      'Cushion the head',
      'Place in recovery position after the seizure ends',
      'Stay with the person until fully recovered',
    ],
    donts: [
      'Don\'t restrain the person\'s movements',
      'Don\'t put anything in their mouth',
      'Don\'t try to hold them down or stop the shaking',
      'Don\'t give food or water until fully recovered',
    ],
  },
  {
    id: "heat-stroke",
    title: 'Heat Stroke & Heat Exhaustion',
    category: 'Environmental & Allergic',
    severity: 'CRITICAL',
    estimatedTime: '~15–30 min',
    overview:
      'Heat stroke occurs when the body\'s temperature regulation fails, causing core temperature to exceed 40°C. Unlike heat exhaustion, heat stroke is a true emergency: the person may stop sweating, become confused, and lose consciousness. Rapid cooling is life-saving.',
    quickActionBadge: 'Cool RAPIDLY',
    hasArGuide: false,
    steps: [
      {
        stepNumber: 1,
        instruction: 'Recognise Heat Stroke vs Exhaustion',
        detail:
          'Heat exhaustion: heavy sweating, weakness, cold/clammy skin, nausea. Heat stroke: hot/dry/red skin, confusion, rapid pulse, temperature above 40°C, possibly unconscious. Heat stroke is a medical emergency.',
        criticalWarning: 'If the person is confused, has stopped sweating, or is unconscious, assume heat stroke and call 112.',
        audioText: 'Check for hot dry skin, confusion, or unconsciousness. If present, this is heat stroke — call 112 now.',
      },
      {
        stepNumber: 2,
        instruction: 'Move to a Cool Environment',
        detail:
          'Get the person into shade or an air-conditioned building immediately. Remove excess clothing to allow heat dissipation.',
        audioText: 'Move the person into shade or air conditioning. Remove excess clothing.',
      },
      {
        stepNumber: 3,
        instruction: 'Begin Rapid Cooling',
        detail:
          'Use every available method: apply cold water or ice packs to the neck, armpits, and groin (where large blood vessels are close to the surface). Fan the person. If available, immerse in cold water up to the neck.',
        audioText: 'Apply cold water and ice packs to the neck, armpits, and groin. Fan the person aggressively.',
      },
      {
        stepNumber: 4,
        instruction: 'Hydrate (If Conscious & Alert)',
        detail:
          'If the person is conscious and able to swallow, give small sips of cool water or an electrolyte drink. Do not force fluids. Do NOT give fluids to anyone who is confused or vomiting.',
        criticalWarning: 'Do NOT give fluids if the person is confused, vomiting, or unconscious.',
        audioText: 'If the person is alert, give small sips of cool water. Do not force fluids.',
      },
      {
        stepNumber: 5,
        instruction: 'Monitor & Await EMS',
        detail:
          'Continue cooling until the skin feels cool to the touch or EMS arrives. Monitor breathing and consciousness. Be prepared to start CPR if the person becomes unresponsive.',
        audioText: 'Continue cooling until help arrives. Monitor breathing and be ready to start CPR if needed.',
      },
    ],
    dos: [
      'Cool aggressively — ice packs to neck, armpits, groin',
      'Fan while applying water to the skin',
      'Hydrate with small sips if conscious and alert',
      'Monitor for deterioration',
    ],
    donts: [
      'Don\'t give aspirin or paracetamol (they don\'t help heat stroke)',
      'Don\'t give fluids to anyone who is confused or vomiting',
      'Don\'t delay cooling to take the temperature',
      'Don\'t leave the person unattended',
    ],
  },
];
