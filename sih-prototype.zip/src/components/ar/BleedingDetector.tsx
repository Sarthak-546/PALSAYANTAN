import { useCallback, useEffect, useRef } from 'react';

interface BleedingDetectorProps {
  /** The live camera <video> element to sample frames from. */
  videoRef: React.RefObject<HTMLVideoElement | null>;
  /** Called when blood/wound is detected; coords are normalized 0..1. */
  onWoundStatus: (coords: { x: number; y: number } | null) => void;
}

/**
 * Perform real-time edge-computed wound detection locally.
 */
export const BleedingDetector = ({ videoRef, onWoundStatus }: BleedingDetectorProps) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    // 320x240 for performance
    const canvas = document.createElement('canvas');
    canvas.width = 320;
    canvas.height = 240;
    canvasRef.current = canvas;
  }, []);

  const processFrame = useCallback(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.readyState < 2) return;

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const { data } = imageData;

    let sumX = 0;
    let sumY = 0;
    let count = 0;

    for (let y = 0; y < canvas.height; y++) {
      for (let x = 0; x < canvas.width; x++) {
        const i = (y * canvas.width + x) * 4;
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];

        // Pixel clustering logic
        if (r > 130 && r > g * 1.45 && r > b * 1.45 && (r - g) > 35) {
          sumX += x;
          sumY += y;
          count++;
        }
      }
    }

    // Only report if clustering density is significant (at least 5% of pixels)
    if (count > (canvas.width * canvas.height * 0.05)) {
      onWoundStatus({
        x: sumX / count / canvas.width,
        y: sumY / count / canvas.height,
      });
    } else {
      onWoundStatus(null);
    }
  }, [videoRef, onWoundStatus]);

  useEffect(() => {
    const interval = setInterval(processFrame, 200); // 5 FPS
    return () => clearInterval(interval);
  }, [processFrame]);

  return null;
};

export default BleedingDetector;