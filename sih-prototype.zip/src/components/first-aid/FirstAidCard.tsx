import type { EmergencyScenario } from '../../data/emergencyScenarios';

interface FirstAidCardProps {
  scenario: EmergencyScenario;
  onSelect: () => void;
  className?: string;
}

const SEVERITY_STYLES: Record<EmergencyScenario['severity'], { bg: string; text: string; ring: string }> = {
  CRITICAL: { bg: 'bg-red-100', text: 'text-red-700', ring: 'ring-red-200' },
  URGENT: { bg: 'bg-amber-100', text: 'text-amber-700', ring: 'ring-amber-200' },
  STABLE: { bg: 'bg-green-100', text: 'text-green-700', ring: 'ring-green-200' },
};

const CATEGORY_EMOJI: Record<EmergencyScenario['category'], string> = {
  'Critical Life Support': '❤️‍🩹',
  'Trauma & Injury': '🩹',
  'Environmental & Allergic': '🌡️',
};

export const FirstAidCard = ({ scenario, onSelect, className = '' }: FirstAidCardProps) => {
  const sev = SEVERITY_STYLES[scenario.severity];

  return (
    <div
      onClick={onSelect}
      className={`group relative bg-white rounded-2xl shadow-md hover:shadow-xl ring-1 ${sev.ring} transition-all cursor-pointer overflow-hidden ${className}`}
    >
      {/* Severity ribbon */}
      <div className={`absolute top-0 left-0 right-0 h-1 ${sev.bg.replace('100', '500')}`} />

      <div className="p-5 pt-4">
        {/* Top row: category + severity */}
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs text-gray-500 font-medium tracking-wide uppercase">
            {CATEGORY_EMOJI[scenario.category]} {scenario.category}
          </span>
          <span className={`text-[10px] font-black tracking-wider px-2.5 py-0.5 rounded-full ${sev.bg} ${sev.text}`}>
            {scenario.severity}
          </span>
        </div>

        {/* Title */}
        <h3 className="text-lg font-bold text-gray-900 mb-1.5 group-hover:text-blue-700 transition-colors">
          {scenario.title}
        </h3>

        {/* Overview */}
        <p className="text-gray-600 text-sm leading-relaxed mb-4 line-clamp-2">
          {scenario.overview}
        </p>

        {/* Meta row */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="px-2.5 py-1 bg-blue-50 text-blue-700 text-[11px] font-semibold rounded-full">
            {scenario.steps.length} Steps
          </span>
          <span className="px-2.5 py-1 bg-gray-100 text-gray-600 text-[11px] font-medium rounded-full">
            {scenario.estimatedTime}
          </span>
          {scenario.hasArGuide && (
            <span className="px-2.5 py-1 bg-purple-50 text-purple-700 text-[11px] font-semibold rounded-full">
              AR Guide
            </span>
          )}
        </div>
      </div>

      {/* Quick-action footer */}
      <div className="px-5 py-3 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
        <span className="text-xs font-semibold text-red-600 tracking-wide">
          ⚡ {scenario.quickActionBadge}
        </span>
        <svg className="w-4 h-4 text-gray-400 group-hover:text-blue-600 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
        </svg>
      </div>
    </div>
  );
};
