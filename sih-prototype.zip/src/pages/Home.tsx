import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useEmergencySession } from '../contexts/EmergencySessionContext';
import { Button } from '../components/ui/Button';
import { StatusIndicator } from '../components/ui/StatusIndicator';
import { Logo } from '../components/ui/Logo';
import { ThemeToggle } from '../components/ui/ThemeToggle';
import { ROUTES, arFirstAidPath } from '../routes';

export const Home = () => {
  const navigate = useNavigate();
  const { demoMode, setDemoMode } = useEmergencySession();
  const [initializing, setInitializing] = useState(true);
  const [systemsReady, setSystemsReady] = useState({
    camera: false,
    ai: false,
    offline: false,
    gps: false,
  });

  useEffect(() => {
    // Staged "boot" animation. Timers are cleared on unmount so leaving Home early is safe.
    const timers = [
      window.setTimeout(() => setSystemsReady(p => ({ ...p, camera: true })), 500),
      window.setTimeout(() => setSystemsReady(p => ({ ...p, ai: true })), 1000),
      window.setTimeout(() => setSystemsReady(p => ({ ...p, offline: true })), 1500),
      window.setTimeout(() => {
        setSystemsReady(p => ({ ...p, gps: true }));
        setInitializing(false);
      }, 2000),
    ];
    return () => timers.forEach(window.clearTimeout);
  }, []);

  if (initializing) {
    return (
      <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center px-6 text-white">
        <Logo className="mb-8" size="large" />
        <h1 className="text-4xl font-bold mb-4 text-center">
          AR Emergency First Aid Assistant
        </h1>
        <p className="text-lg text-gray-300 mb-8 max-w-md text-center">
          Real-time guidance when every second matters.
        </p>

        <div className="space-y-4 w-full max-w-md">
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
            <span className="text-sm">Camera system</span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
            <span className="text-sm">AI assessment</span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
            <span className="text-sm">Offline assistant</span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
            <span className="text-sm">GPS</span>
          </div>
        </div>

        <div className="mt-8 flex items-center space-x-3 text-xs text-gray-400">
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          <span>System Ready</span>
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          <span>Prototype</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
      <div className="max-w-md mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center space-x-3">
            <Logo size="small" className="h-8 w-8" />
            <h1 className="text-2xl font-bold">
              AR Emergency Assistant
            </h1>
          </div>
          <ThemeToggle />
        </div>

        {/* Quick Access Emergency Protocols */}
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">
            Quick Access
          </h2>
          <p className="text-muted-foreground mb-4 text-sm">
            Jump directly to critical emergency procedures
          </p>
          <div className="grid grid-cols-3 gap-3">
            <Button
              variant="outline"
              onClick={() => navigate(arFirstAidPath('cpr'))}
              className="h-12 w-full text-sm font-semibold"
            >
              CPR
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate(arFirstAidPath('bleeding'))}
              className="h-12 w-full text-sm font-semibold"
            >
              Bleeding
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate(arFirstAidPath('choking'))}
              className="h-12 w-full text-sm font-semibold"
            >
              Choking
            </Button>
          </div>
        </div>

        {/* Primary Action Card */}
        <div className="bg-card text-card-foreground rounded-xl shadow-md p-6 mb-8">
          <h2 className="text-2xl font-semibold mb-2">
            Need emergency assistance?
          </h2>
          <p className="text-muted-foreground mb-6 text-sm">
            Start an assisted emergency assessment.
          </p>
          <Button
            variant="primary"
            size="large"
            onClick={() => navigate(ROUTES.emergencyScan)}
            className="w-full font-bold"
          >
            START EMERGENCY SCAN
          </Button>
          <div className="mt-4 space-y-3">
            <Button
              variant="outline"
              onClick={() => navigate(ROUTES.firstAid)}
              className="w-full"
            >
              FIRST AID LIBRARY
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate(ROUTES.location)}
              className="w-full"
            >
              SHARE LOCATION
            </Button>
          </div>
        </div>

        {/* Status Indicators Bar */}
        <div className="bg-card text-card-foreground rounded-xl shadow-md p-4">
          <div className="grid grid-cols-4 gap-2 text-center text-xs">
            <div>
              <div className="text-muted-foreground font-medium">Camera</div>
              <div className="mt-1 flex justify-center">
                <StatusIndicator
                  status={systemsReady.camera ? 'ready' : 'offline'}
                  label={systemsReady.camera ? 'READY' : 'OFFLINE'}
                />
              </div>
            </div>
            <div>
              <div className="text-muted-foreground font-medium">AI Engine</div>
              <div className="mt-1 flex justify-center">
                <StatusIndicator
                  status={systemsReady.ai ? 'ready' : 'offline'}
                  label={systemsReady.ai ? 'READY' : 'OFFLINE'}
                />
              </div>
            </div>
            <div>
              <div className="text-muted-foreground font-medium">GPS</div>
              <div className="mt-1 flex justify-center">
                <StatusIndicator
                  status={systemsReady.gps ? 'ready' : 'offline'}
                  label={systemsReady.gps ? 'READY' : 'OFFLINE'}
                />
              </div>
            </div>
            <div>
              <div className="text-muted-foreground font-medium">Offline</div>
              <div className="mt-1 flex justify-center">
                <StatusIndicator
                  status={systemsReady.offline ? 'ready' : 'offline'}
                  label={systemsReady.offline ? 'READY' : 'OFFLINE'}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;