import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Search, Volume2, VolumeX } from 'lucide-react';
import { useEmergencySession } from '../contexts/EmergencySessionContext';
import { FirstAidCard } from '../components/first-aid/FirstAidCard';
import { emergencyScenarios } from '../data/emergencyScenarios';
import type { EmergencyScenario } from '../data/emergencyScenarios';
import { ROUTES, firstAidDetailPath } from '../routes';

const CATEGORIES: Array<EmergencyScenario['category']> = [
  'Critical Life Support',
  'Trauma & Injury',
  'Environmental & Allergic',
];

export const FirstAidLibrary = () => {
  const navigate = useNavigate();
  const { voiceGuidance, setVoiceGuidance } = useEmergencySession();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<EmergencyScenario['category'] | null>(null);

  const filteredScenarios = emergencyScenarios.filter((s) => {
    const matchesSearch =
      !searchTerm ||
      s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.overview.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !activeCategory || s.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sticky header */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <button
            onClick={() => navigate(ROUTES.home)}
            className="flex items-center gap-1.5 text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium"
          >
            <ArrowLeft className="h-4 w-4" />
            Home
          </button>

          <h1 className="text-base sm:text-lg font-bold text-gray-900 tracking-tight">
            First Aid Library
          </h1>

          <button
            onClick={() => setVoiceGuidance(!voiceGuidance)}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full transition-colors ${
              voiceGuidance
                ? 'bg-blue-100 text-blue-700'
                : 'bg-gray-100 text-gray-500'
            }`}
          >
            {voiceGuidance ? <Volume2 className="h-3.5 w-3.5" /> : <VolumeX className="h-3.5 w-3.5" />}
            {voiceGuidance ? 'Voice On' : 'Voice Off'}
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 pt-5 pb-10">
        {/* Search bar */}
        <div className="relative mb-4">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search emergencies…"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm placeholder:text-gray-400"
          />
        </div>

        {/* Category chips */}
        <div className="flex flex-wrap gap-2 mb-6">
          <button
            onClick={() => setActiveCategory(null)}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-full transition-colors ${
              activeCategory === null
                ? 'bg-gray-900 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(activeCategory === cat ? null : cat)}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-full transition-colors ${
                activeCategory === cat
                  ? 'bg-gray-900 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Results */}
        {filteredScenarios.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-gray-400 text-sm">No scenarios match your search. Try adjusting your filters.</p>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {filteredScenarios.map((scenario) => (
              <FirstAidCard
                key={scenario.id}
                scenario={scenario}
                onSelect={() => navigate(firstAidDetailPath(scenario.id))}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default FirstAidLibrary;
