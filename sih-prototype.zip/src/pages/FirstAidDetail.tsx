import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, ArrowLeft, CheckCircle2, ChevronLeft, ChevronRight, Shield, Volume2, VolumeX, XCircle } from 'lucide-react';
import { AudioGuidance } from '../components/ar/AudioGuidance';
import { useEmergencySession } from '../contexts/EmergencySessionContext';
import { useScenario } from '../hooks/useScenario';
import { ROUTES, arFirstAidPath } from '../routes';

const SEVERITY_STYLES: Record<string, string> = {
  CRITICAL: 'bg-red-100 text-red-700',
  URGENT: 'bg-amber-100 text-amber-700',
  STABLE: 'bg-green-100 text-green-700',
};

export const FirstAidDetail = () => {
  const navigate = useNavigate();
  const { voiceGuidance, setVoiceGuidance } = useEmergencySession();
  const { scenario } = useScenario();
  const [currentStep, setCurrentStep] = useState(0);
  const [showDos, setShowDos] = useState(true);

  useEffect(() => {
    setCurrentStep(0);
  }, [scenario?.id]);

  // ── Not found ──────────────────────────────────────────────────────────────
  if (!scenario) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-6">
        <h1 className="text-2xl font-bold text-red-500 mb-3">Scenario Not Found</h1>
        <p className="text-gray-500 mb-6 text-sm">The requested emergency scenario could not be loaded.</p>
        <button
          onClick={() => navigate(ROUTES.firstAid)}
          className="px-5 py-2.5 bg-gray-900 text-white text-sm font-semibold rounded-xl hover:bg-gray-800 transition-colors"
        >
          Return to Library
        </button>
      </div>
    );
  }

  const steps = scenario.steps;
  const step = steps[currentStep];
  const isLast = currentStep === steps.length - 1;
  const progress = ((currentStep + 1) / steps.length) * 100;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Voice guidance */}
      <AudioGuidance text={step.audioText ?? step.instruction} isActive={voiceGuidance} />

      {/* Sticky header */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="max-w-xl mx-auto px-4 py-3 flex items-center justify-between">
          <button
            onClick={() => navigate(ROUTES.firstAid)}
            className="flex items-center gap-1.5 text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium"
          >
            <ArrowLeft className="h-4 w-4" />
            Library
          </button>

          <span className={`text-[10px] font-black tracking-wider px-2.5 py-0.5 rounded-full ${SEVERITY_STYLES[scenario.severity] ?? ''}`}>
            {scenario.severity}
          </span>

          <button
            onClick={() => setVoiceGuidance(!voiceGuidance)}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full transition-colors ${
              voiceGuidance ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-500'
            }`}
          >
            {voiceGuidance ? <Volume2 className="h-3.5 w-3.5" /> : <VolumeX className="h-3.5 w-3.5" />}
          </button>
        </div>

        {/* Progress bar */}
        <div className="h-1 bg-gray-100">
          <div
            className="h-full bg-blue-600 transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </header>

      <main className="max-w-xl mx-auto px-4 pt-5 pb-10">
        {/* Title & meta */}
        <div className="mb-5">
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900 mb-1.5">{scenario.title}</h1>
          <div className="flex flex-wrap items-center gap-2 text-xs text-gray-500">
            <span>{scenario.category}</span>
            <span>·</span>
            <span>{scenario.estimatedTime}</span>
            <span>·</span>
            <span>{scenario.steps.length} steps</span>
          </div>
        </div>

        {/* Overview card */}
        <div className="bg-white rounded-2xl shadow-sm ring-1 ring-gray-100 p-4 mb-5">
          <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1.5">Overview</h2>
          <p className="text-gray-700 text-sm leading-relaxed">{scenario.overview}</p>
        </div>

        {/* ── Step card ── */}
        <div className="bg-white rounded-2xl shadow-md ring-1 ring-gray-100 overflow-hidden mb-5">
          {/* Step header */}
          <div className="px-5 pt-4 pb-3 border-b border-gray-100 flex items-center justify-between">
            <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">
              Step {step.stepNumber} of {steps.length}
            </span>
            <div className="flex gap-1">
              {steps.map((_, i) => (
                <div
                  key={i}
                  className={`h-1.5 rounded-full transition-all ${
                    i === currentStep ? 'w-5 bg-blue-600' : i < currentStep ? 'w-1.5 bg-blue-300' : 'w-1.5 bg-gray-200'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Step content */}
          <div className="px-5 py-5 space-y-3">
            <h3 className="text-lg font-bold text-gray-900">{step.instruction}</h3>
            <p className="text-gray-600 text-sm leading-relaxed">{step.detail}</p>
            {step.criticalWarning && (
              <div className="flex items-start gap-2.5 bg-red-50 border border-red-200 rounded-xl p-3">
                <AlertTriangle className="h-4 w-4 text-red-500 flex-shrink-0 mt-0.5" />
                <p className="text-red-700 text-xs font-medium leading-snug">{step.criticalWarning}</p>
              </div>
            )}
          </div>

          {/* Navigation */}
          <div className="px-5 pb-4 flex items-center justify-between gap-3">
            <button
              onClick={() => setCurrentStep((s) => s - 1)}
              disabled={currentStep === 0}
              className="flex items-center gap-1 text-sm font-semibold text-gray-500 hover:text-gray-900 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="h-4 w-4" />
              Previous
            </button>

            {isLast ? (
              <button
                onClick={() => navigate(ROUTES.firstAid)}
                className="px-5 py-2 bg-green-600 hover:bg-green-500 text-white text-sm font-bold rounded-xl transition-colors"
              >
                ✓ Finish
              </button>
            ) : (
              <button
                onClick={() => setCurrentStep((s) => s + 1)}
                className="flex items-center gap-1 px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold rounded-xl transition-colors"
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>

        {/* ── Do's & Don'ts ── */}
        <div className="bg-white rounded-2xl shadow-sm ring-1 ring-gray-100 overflow-hidden mb-5">
          <div className="flex border-b border-gray-100">
            <button
              onClick={() => setShowDos(true)}
              className={`flex-1 py-2.5 text-xs font-bold tracking-wider text-center transition-colors ${
                showDos ? 'text-green-700 bg-green-50 border-b-2 border-green-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              ✅ DO&apos;s
            </button>
            <button
              onClick={() => setShowDos(false)}
              className={`flex-1 py-2.5 text-xs font-bold tracking-wider text-center transition-colors ${
                !showDos ? 'text-red-700 bg-red-50 border-b-2 border-red-600' : 'text-gray-400 hover:text-gray-600'
              }`}
            >
              ❌ DON&apos;Ts
            </button>
          </div>
          <ul className="px-5 py-4 space-y-2.5">
            {(showDos ? scenario.dos : scenario.donts).map((item, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm text-gray-700">
                {showDos ? (
                  <CheckCircle2 className="h-4 w-4 text-green-500 flex-shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-400 flex-shrink-0 mt-0.5" />
                )}
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* ── Action buttons ── */}
        <div className="space-y-2.5">
          {scenario.hasArGuide && (
            <button
              onClick={() => navigate(scenario.arRoute ?? arFirstAidPath(scenario.id))}
              className="w-full flex items-center justify-center gap-2 py-3 bg-purple-600 hover:bg-purple-500 text-white text-sm font-bold rounded-2xl shadow-lg shadow-purple-600/20 transition-all active:scale-[0.98]"
            >
              <Shield className="h-4 w-4" />
              Open Live AR Guidance
            </button>
          )}
          <button
            onClick={() => navigate(ROUTES.firstAid)}
            className="w-full text-sm font-medium text-gray-400 hover:text-gray-700 py-2 transition-colors"
          >
            ← Back to Library
          </button>
        </div>
      </main>
    </div>
  );
};

export default FirstAidDetail;
