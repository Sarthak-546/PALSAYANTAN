import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Activity, AlertTriangle, ArrowLeft } from 'lucide-react';
import { CameraViewport } from '../components/camera/CameraViewport';
import { SternumOverlay } from '../components/ar/SternumOverlay';
import { ScanOverlay } from '../components/ar/ScanOverlay';
import { BleedingDetector } from '../components/ar/BleedingDetector';
import { AudioGuidance } from '../components/ar/AudioGuidance';
import { CPRMetronome } from '../components/ar/CPRMetronome';
import { EmergencyActionPanel } from '../components/emergency/EmergencyActionPanel';
import { ThemeToggle } from '../components/ui/ThemeToggle';
import { useEmergencySession } from '../contexts/EmergencySessionContext';
import { ROUTES } from '../routes';

type Emergency = 'none' | 'cpr' | 'bleeding';

const INSTRUCTIONS: Record<Emergency, string> = {
  none: 'Analyzing scene. Please select the emergency type below.',
  cpr: 'Push to the beat (110 BPM). Place hands on the red target and compress hard and fast.',
  bleeding: 'Severe bleeding detected. Apply firm, direct pressure to the wound with a clean cloth immediately.',
};

/**
 * Convert a normalized (0..1) point in the VIDEO frame to pixels inside the
 * <video> element's box, accounting for `object-cover` cropping.
 */
function normalizedToPixels(nx: number, ny: number, video: HTMLVideoElement) {
  const cw = video.clientWidth;
  const ch = video.clientHeight;
  const vw = video.videoWidth;
  const vh = video.videoHeight;

  // Video metadata not ready yet: plain multiply, as a safe fallback.
  if (!vw || !vh) return { x: nx * cw, y: ny * ch };

  const scale = Math.max(cw / vw, ch / vh); // object-cover scale
  const offsetX = (vw * scale - cw) / 2; // cropped amount on each side
  const offsetY = (vh * scale - ch) / 2;
  return { x: nx * vw * scale - offsetX, y: ny * vh * scale - offsetY };
}

export const EmergencyScan = () => {
  const navigate = useNavigate();
  const { voiceGuidance } = useEmergencySession();

  const videoRef = useRef<HTMLVideoElement | null>(null);

  const [activeEmergency, setActiveEmergency] = useState<Emergency>('none');
  const [sternumPoint, setSternumPoint] = useState<{ x: number; y: number } | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [poseError, setPoseError] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(true);
  const [scanProgress, setScanProgress] = useState(0);

  const handleCameraError = useCallback((msg: string) => setCameraError(msg), []);

  // Intro "scanning the scene" sweep (~2s).
  useEffect(() => {
    const id = window.setInterval(() => {
      setScanProgress((p) => {
        if (p >= 100) {
          window.clearInterval(id);
          setIsScanning(false);
          return 100;
        }
        return p + 5;
      });
    }, 100);
    return () => window.clearInterval(id);
  }, []);

  // MediaPipe Pose tracking: only runs while the CPR protocol is active.
  useEffect(() => {
    if (activeEmergency !== 'cpr') {
      setSternumPoint(null);
      setPoseError(null);
      return;
    }

    // MediaPipe comes from the <script> tag in index.html, so read it from window.
    const Pose = (window as any).Pose;
    if (typeof Pose !== 'function') {
      setPoseError('Pose tracking is unavailable (MediaPipe script not loaded). Follow the voice guidance.');
      return;
    }

    let isSubscribed = true;
    let animFrameId = 0;
    let pose: any = null;

    try {
      pose = new Pose({
        locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}`,
      });

      pose.setOptions({
        selfieMode: false,
        modelComplexity: 1,
        smoothLandmarks: true,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5,
      });

      pose.onResults((results: any) => {
        if (!isSubscribed) return;
        const video = videoRef.current;
        const landmarks = results?.poseLandmarks;
        const left = landmarks?.[11]; // left shoulder
        const right = landmarks?.[12]; // right shoulder

        if (!video || !left || !right) {
          setSternumPoint(null);
          return;
        }

        // Sternum estimate: shoulder midpoint, dropped ~45% of shoulder width toward the chest.
        const midX = (left.x + right.x) / 2;
        const shoulderWidth = Math.hypot(left.x - right.x, left.y - right.y);
        const midY = (left.y + right.y) / 2 + shoulderWidth * 0.45;

        // Normalized (0..1) -> real pixels in the video box.
        setSternumPoint(normalizedToPixels(midX, midY, video));
      });
    } catch (err) {
      console.error('Failed to initialise pose detection:', err);
      setPoseError('Pose tracking failed to start. Follow the voice guidance.');
      return;
    }

    let busy = false;
    const processFrame = async () => {
      if (!isSubscribed) return;
      const video = videoRef.current;
      if (!busy && video && video.readyState >= 2 && !video.paused) {
        busy = true;
        try {
          await pose.send({ image: video });
        } catch (err) {
          console.error('Pose frame error:', err);
        } finally {
          busy = false;
        }
      }
      if (isSubscribed) animFrameId = requestAnimationFrame(processFrame);
    };
    processFrame();

    return () => {
      isSubscribed = false;
      if (animFrameId) cancelAnimationFrame(animFrameId);
      try {
        pose?.close?.();
      } catch {
        /* ignore */
      }
    };
  }, [activeEmergency]);

  const instructionText = INSTRUCTIONS[activeEmergency];

  return (
    <div className="fixed inset-0 z-0 w-full h-screen bg-black text-white overflow-hidden">
      {/* Invisible voice engine: re-speaks whenever the instruction changes */}
      <AudioGuidance text={instructionText} isActive={voiceGuidance} />

      {/* 110 BPM audible metronome click (Web Audio API, no files needed) */}
      <CPRMetronome isActive={activeEmergency === 'cpr'} />
      {/* Real-time bleeding detector */}
      <BleedingDetector
        videoRef={videoRef}
        onWoundStatus={(coords) => {
          if (coords && activeEmergency === 'none') {
            setActiveEmergency('bleeding');
          }
        }}
      />

      {/* ── Full-screen camera + AR overlays ── */}
      <div className="absolute inset-0">
        <CameraViewport videoRef={videoRef} onError={handleCameraError} className="w-full h-full object-cover" />
        <ScanOverlay isScanning={isScanning} scanProgress={scanProgress} />
        {activeEmergency === 'cpr' && sternumPoint && (
          <SternumOverlay targetX={sternumPoint.x} targetY={sternumPoint.y} />
        )}
      </div>

      {/* ── Floating HUD Top Bar ── */}
      <div className="absolute top-4 inset-x-4 z-40 flex items-center justify-between pointer-events-none">
        {/* Exit button & theme toggle */}
        <div className="flex gap-2 pointer-events-auto">
          <button
            onClick={() => navigate(ROUTES.home)}
            className="flex items-center gap-1.5 bg-black/40 backdrop-blur-md border border-white/10 text-white rounded-full px-4 py-1.5 text-xs font-semibold hover:bg-black/60 transition-colors"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Exit
          </button>
          <ThemeToggle />
        </div>

        {/* Live AR badge */}
        <span className="pointer-events-none flex items-center gap-1.5 bg-black/40 backdrop-blur-md border border-white/10 rounded-full px-3 py-1.5 text-xs font-semibold tracking-wide text-white">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-red-500" />
          </span>
          LIVE AR PROTOCOL
        </span>
      </div>

      {/* ── Error banner ── */}
      {(cameraError || poseError) && (
        <div className="absolute left-4 right-4 top-16 z-50 rounded-2xl border border-amber-500/50 bg-amber-950/80 backdrop-blur-md p-3 text-xs text-amber-100">
          {cameraError ?? poseError}. Guidance and SOS still work.
        </div>
      )}

      {/* ── Instruction Text – Top HUD pill ── */}
      <div className="absolute top-16 inset-x-4 max-w-md mx-auto z-40 pointer-events-none">
        <div className="bg-slate-950/80 backdrop-blur-md border border-white/10 px-4 py-2 rounded-2xl text-center shadow-lg">
          <p className="text-xs sm:text-sm font-medium text-slate-100 line-clamp-2">
            {instructionText}
          </p>
        </div>
      </div>

      {/* ── PiP Reference Video (CPR active) ── */}
      {activeEmergency === 'cpr' && (
        <div className="absolute top-32 right-4 z-40 w-28 sm:w-36 rounded-2xl overflow-hidden border border-white/20 shadow-2xl bg-black/80 backdrop-blur-md pointer-events-auto">
          <div className="bg-red-600/90 px-2 py-0.5 text-[9px] font-bold tracking-wider text-white text-center uppercase">
            Demo Guide
          </div>
          <video
            src="/videos/h.mp4"
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-20 sm:h-24 object-cover"
            onError={(e) => {
              (e.currentTarget as HTMLVideoElement).src = '/h.mp4';
            }}
          />
        </div>
      )}

      {/* ── Slim Bottom Panel – SOS + triage only ── */}
      <div className="absolute bottom-4 inset-x-4 max-w-sm mx-auto z-40 flex flex-col gap-2 pointer-events-auto">
        {/* Triage selection or reset */}
        {activeEmergency === 'none' ? (
          <div className="bg-slate-950/80 backdrop-blur-xl border border-white/10 rounded-2xl p-3 shadow-2xl space-y-2">
            <p className="text-center text-[10px] font-semibold uppercase tracking-widest text-slate-400">
              Select Emergency Type
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setActiveEmergency('cpr')}
                className="flex-1 flex items-center justify-center gap-1.5 bg-red-600/90 hover:bg-red-500 text-white text-xs font-bold py-2.5 rounded-2xl transition-all active:scale-95"
              >
                <Activity className="h-3.5 w-3.5" />
                Cardiac Arrest
              </button>
              <button
                onClick={() => setActiveEmergency('bleeding')}
                className="flex-1 flex items-center justify-center gap-1.5 bg-amber-600/90 hover:bg-amber-500 text-white text-xs font-bold py-2.5 rounded-2xl transition-all active:scale-95"
              >
                <AlertTriangle className="h-3.5 w-3.5" />
                Severe Bleeding
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setActiveEmergency('none')}
            className="text-[11px] font-semibold text-slate-400 hover:text-white py-1 text-center transition-colors"
          >
            ← Reset Protocol
          </button>
        )}

        {/* SOS action */}
        <div className="bg-slate-950/80 backdrop-blur-xl border border-white/10 rounded-2xl p-3 shadow-2xl">
          <EmergencyActionPanel />
        </div>
      </div>
    </div>
  );
};

export default EmergencyScan;
